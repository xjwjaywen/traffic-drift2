Supplementary Material S3: 11-home IoT final-window records

This archive contains the frozen evaluation CSVs and reports, per-row final-window predictions for all four methods, and the protocol, code, and metadata used for this analysis. Home/seed predictions use raw archive row order after the development window; the public archive and official device inventory are needed to rescore them. See code/Experiment/unsw_home_temporal_v1/FINAL_HOLDOUT_PROTOCOL.md.

The raw public traffic archive, intermediate final_features.npy arrays, source checkpoints, and training caches are not copied here. Their hashes remain in the original complete.json markers and were verified at export. This is a curated mixed-protocol, closed-set device-type stress test, not an encrypted-only IoT deployment or an independent-site replication. The five seeds within each home are overlapping repeats.

MANIFEST.json lists the SHA256 and byte size of each copied file.
